import 'package:flutter/material.dart';
import 'dart:async'; // Timer를 사용하기 위해 필요

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '현재 시각',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const CurrentTimeScreen(),
    );
  }
}

class CurrentTimeScreen extends StatefulWidget {
  const CurrentTimeScreen({Key? key}) : super(key: key);

  @override
  State<CurrentTimeScreen> createState() => _CurrentTimeScreenState();
}

class _CurrentTimeScreenState extends State<CurrentTimeScreen> {
  late String _currentTime; // 현재 시각을 저장할 변수
  late Timer _timer; // 1초마다 갱신하기 위한 Timer

  @override
  void initState() {
    super.initState();
    _currentTime = _getCurrentTime(); // 초기값 설정
    _startTimer(); // 타이머 시작
  }

  @override
  void dispose() {
    _timer.cancel(); // 타이머 해제
    super.dispose();
  }

  // 현재 시간을 가져오는 함수
  String _getCurrentTime() {
    return DateTime.now().toLocal().toString().split('.')[0]; // 초 단위까지 표시
  }

  // 타이머를 시작하는 함수
  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _currentTime = _getCurrentTime(); // 매초 현재 시간 갱신
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('현재 시각'),
        centerTitle: true, // 제목 중앙 정렬
      ),
      body: Center(
        child: Text(
          _currentTime,
          style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
