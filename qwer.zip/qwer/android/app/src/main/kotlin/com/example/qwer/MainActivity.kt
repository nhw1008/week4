package com.example.qwer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
